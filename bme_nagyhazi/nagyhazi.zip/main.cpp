//
//  main.cpp
//  nagyhazi
//
//  Created by Gergo Por on 2022. 05. 12..
//

#include <iostream>
#include "app.hpp"
#include "memtrace.hpp"

int main(int argc, const char * argv[]) {
    App app;
    return 0;
}
